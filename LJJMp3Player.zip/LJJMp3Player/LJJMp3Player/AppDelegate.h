//
//  AppDelegate.h
//  LJJMp3Player
//
//  Created by Mac on 15-3-14.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

