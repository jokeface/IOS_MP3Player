//
//  ViewController.h
//  LJJMp3Player
//
//  Created by Mac on 15-3-14.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Tool.h"
#import "Music.h"
#import <AVFoundation/AVFoundation.h>
#import "LjjLRCcell.h"
#import "ListCell.h"

@interface ViewController : UIViewController<AVAudioPlayerDelegate,UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>


@end

