//
//  ViewController.m
//  LJJMp3Player
//
//  Created by Mac on 15-3-14.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import "ViewController.h"
#import <Accelerate/Accelerate.h>
@interface ViewController ()<UIScrollViewDelegate>
{
    int count;
    AVAudioPlayer* musicPlayer;
    NSMutableArray* LRCArry;
    NSMutableDictionary* LRCdic;
    NSMutableArray* musicArray;
    NSTimer* timer;
    CGFloat centerPointY;
    CGRect lastTable;
    CGRect lasrPhoto;
    BOOL isFirst;
    CGRect lastlist;
    
}

@property (strong, nonatomic) IBOutlet UIImageView *backGroundImage;
@property (weak, nonatomic) IBOutlet UILabel *MusicName;

@property (weak, nonatomic) IBOutlet UILabel *singerName;

@property (weak, nonatomic) IBOutlet UILabel *LRCLine;
@property (weak, nonatomic) IBOutlet UILabel *currentTime;
@property (weak, nonatomic) IBOutlet UILabel *totalTime;
@property (weak, nonatomic) IBOutlet UISlider *slider;
@property (weak, nonatomic) IBOutlet UIButton *play_Button;
@property (weak, nonatomic) IBOutlet UIButton *old_button;
@property (weak, nonatomic) IBOutlet UIButton *next_button;
@property (strong,nonatomic)UIButton* slideTime;
@property (weak, nonatomic) IBOutlet UIView *secondView;
@property (weak, nonatomic) IBOutlet UIView *thirdView;
@property(strong,nonatomic) UIImageView* singerPhoto;
@property(strong,nonatomic)UITableView* tableview;
@property(strong,nonatomic)UIScrollView* scroller;
@property(strong,nonatomic)UITableView* ListTableview;
@property (weak, nonatomic) IBOutlet UIButton *listButton;
@end

@implementation ViewController
- (IBAction)musicList:(id)sender {
    [UIView animateWithDuration:0.2 animations:^{
        [self.ListTableview setFrame:CGRectMake(0, self.view.frame.size.height-200, self.view.frame.size.width, 200)];
    }];
}
#pragma mark 获取歌词
-(void)getLRC
{
    LRCArry=NULL;
    LRCdic=NULL;
    LRCArry=[NSMutableArray array];
    LRCdic=[NSMutableDictionary dictionary];
    NSBundle* bund=[NSBundle mainBundle];
    NSString* fileStr=[NSString stringWithFormat:@"%@-%@",[musicArray[count] singerName],[musicArray[count] musicName]];
    NSString* LRCPath=[bund pathForResource:fileStr ofType:@"lrc"];
    NSString* string=[NSString stringWithContentsOfFile:LRCPath encoding:NSUTF8StringEncoding error:nil];
    NSArray * timeLRC=[string componentsSeparatedByString:@"\n"];
    for (int i=0; i<timeLRC.count; i++) {
        if ([self juideLRC:timeLRC[i]]) {
            NSRange range={1,8};
            NSString* timeString=[timeLRC[i] substringWithRange:range];
            NSString* lrcString=[timeLRC[i] substringFromIndex:10];
//                        NSLog(@"%i:%@,%@",i,timeString,lrcString);
            [LRCdic setObject:lrcString forKey:timeString];
            [LRCArry addObject:timeString];
        }
    }
}
//动态显示歌词的方法
-(void)dynamiCLRC:(NSTimeInterval)time
{
    for (int i=0; i<LRCArry.count; i++) {
        //        NSLog(@"%lu",(unsigned long)LRtime);
        //        NSLog(@"%@",[LRCdic objectForKey:LRCArry[0]]);
        NSArray* array=[LRCArry[i] componentsSeparatedByString:@":"];
        double LRtime=[array[0] doubleValue]*60 +[array[1] doubleValue];
        if (i==LRCArry.count-1) {
            if (time>=LRtime) {
                //                NSLog(@"%@",[LRCdic objectForKey:LRCArry[LRCArry.count-1]]);
                [self updateLRc:i];
                self.LRCLine.text=[LRCdic objectForKey:LRCArry[LRCArry.count-1]];
                return;
            }
        }
        else if(i==0)
        {
            
            if (time<=LRtime) {
                //                NSLog(@"%@",[LRCdic objectForKey:LRCArry[0]]);
                self.LRCLine.text=[LRCdic objectForKey:LRCArry[0]];
                [self updateLRc:i];
                return;
            }
        }
        else if ([self isCurrentTime:i withCurrentTime:time]) {
//                        NSLog(@"%@",[LRCdic objectForKey:LRCArry[i]]);
//            [self updateLRc:i];
            self.LRCLine.text=[LRCdic objectForKey:LRCArry[i]];
                        [self updateLRc:i];;
            return;
        }
    }
}

//判断歌曲时间是否在当前歌词和下一行歌词之间
-(BOOL)isCurrentTime:(int)number withCurrentTime:(NSUInteger)time
{
    NSArray* array=[LRCArry[number] componentsSeparatedByString:@":"];
    double LRtime=[array[0] doubleValue]*60 +[array[1] doubleValue];
    NSArray* array1=[LRCArry[number+1] componentsSeparatedByString:@":"];
    double LRtimenext=[array1[0] doubleValue]*60 +[array1[1] doubleValue];
    if (time>=LRtime && time<=LRtimenext) {
        return YES;
    }
    return NO;
    
}
//更新歌词
-(void)updateLRc:(int)number
{
    [self.tableview reloadData];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:number inSection:0];
    NSIndexPath *indexPath2 = [NSIndexPath indexPathForRow:(number-1) inSection:0];
    [self.tableview deselectRowAtIndexPath:indexPath2 animated:YES];
    [self.tableview selectRowAtIndexPath:indexPath animated:YES scrollPosition:UITableViewScrollPositionMiddle];
}

//判断是否是歌词部分的方法
-(BOOL)juideLRC:(NSString*)string
{
    if ([string length]>=10) {
        NSRange range1={0,1};
        NSRange range2={9,1};
        NSRange range3={3,1};
        NSRange range4={6,1};
        NSString* string1=[string substringWithRange:range1];
        NSString* string3=[string substringWithRange:range3];
        NSString* string4=[string substringWithRange:range4];
        NSString* string2=[string substringWithRange:range2];
        if ([string1 isEqualToString:@"["]&&[string2 isEqualToString:@"]"]&&[string3 isEqualToString:@":"]&&[string4 isEqualToString:@"."]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark 定时器设定
-(void)show
{
    self.currentTime.text=[NSString stringWithFormat:@"%02d:%02d",(int)musicPlayer.currentTime/60,(int)musicPlayer.currentTime%60];
    self.totalTime.text=[NSString stringWithFormat:@"%02d:%02d",(int)musicPlayer.duration/60,(int)musicPlayer.duration%60];
    self.slider.value=musicPlayer.currentTime/musicPlayer.duration;
    if (self.slider.value>0.999) {
        [self nextButtonClick];
    }
    [self dynamiCLRC:musicPlayer.currentTime];
}
#pragma mark 点击上一首
- (IBAction)PreviousButtonClick {
    if (count==0) {
        count=musicArray.count-1;
    }
    else
    {
        count--;
    }
        [self.singerPhoto setFrame:CGRectMake(-180, 44, 180, 180)];
        [UIView animateWithDuration:0.8f animations:^{
            [self.singerPhoto setFrame:lasrPhoto];
            
        }];

        [self prepareForMusic:count];
    [self playBUttonClick];
}
#pragma mark 点击下一首
- (IBAction)nextButtonClick {
    if (count==musicArray.count-1) {
        count=0;
    }
    else
    {
        count++;
    }
    if (!isFirst) {
        [self.singerPhoto setFrame:CGRectMake(self.view.frame.size.width+180, 44, 180, 180)];
        [UIView animateWithDuration:0.8f animations:^{
            [self.singerPhoto setFrame:lasrPhoto];
            NSLog(@"是第一页");
            
        }];

    }
        [self prepareForMusic:count];
    [self playBUttonClick];
}
#pragma mark 点击播放按钮
- (IBAction)playBUttonClick{
    if ([musicPlayer isPlaying]) {
        [self.play_Button setImage:[UIImage imageNamed:@"player_btn_play_normal.png"] forState:UIControlStateNormal];
        [self.play_Button setImage:[UIImage imageNamed:@"player_btn_play_highlight.png"] forState:UIControlStateHighlighted];
        [musicPlayer pause];
        [timer setFireDate:[NSDate distantFuture]];
    }
    else
    {
        [self.play_Button setImage:[UIImage imageNamed:@"player_btn_pause_normal.png"] forState:UIControlStateNormal];
        [self.play_Button setImage:[UIImage imageNamed:@"player_btn_pause_highlight.png"] forState:UIControlStateHighlighted];
        [musicPlayer play];
        [timer setFireDate:[NSDate date]];
    }
}
#pragma mark 加载音乐
-(void)prepareForMusic:(int)number
{
    Music* music=musicArray[number];
    NSBundle* bund=[NSBundle mainBundle];
    NSString* str=[NSString stringWithFormat:@"%@-%@",music.singerName,music.musicName];
    NSString* filepath=[bund pathForResource:str ofType:music.type];
    NSError* error=nil;
    NSURL* fileUrl=[NSURL fileURLWithPath:filepath];
    musicPlayer=[[AVAudioPlayer alloc]initWithContentsOfURL:fileUrl error:&error];
    [self getLRC];
    self.MusicName.text=music.musicName;
    self.singerName.text=[NSString stringWithFormat:@"-%@-",music.singerName];
    NSString* photoStr=[NSString stringWithFormat:@"%@.jpg",str];
    [self.backGroundImage setImage:[Tool blurryImage:[UIImage imageNamed:photoStr] withBlurLevel:0.3]];
    [Tool ImageHandleWithImageView:self.singerPhoto andImageName:photoStr];
    
}
#pragma mark 初始化音乐
-(void)initMusic
{
    NSBundle* bund=[NSBundle mainBundle];
    NSArray* array=[NSArray arrayWithContentsOfFile:[bund pathForResource:@"resource" ofType:@"plist"]];
    for (NSDictionary* dic in array) {
        Music* music=[[Music alloc]initWithMusicName:[dic objectForKey:@"musicName"] andSingerName:[dic objectForKey:@"singerName"] andType:[dic objectForKey:@"type"]];
        [musicArray addObject:music];
    }
}
#pragma mark 进度条绑定事件
-(void)selectTime
{
    NSLog(@"%f",self.slider.value);
    
    if (![musicPlayer isPlaying]) {
        [self.play_Button setImage:[UIImage imageNamed:@"player_btn_pause_normal.png"] forState:UIControlStateNormal];
        [self.play_Button setImage:[UIImage imageNamed:@"player_btn_pause_highlight.png"] forState:UIControlStateHighlighted];
}
    musicPlayer.currentTime=self.slider.value * musicPlayer.duration;
    [musicPlayer play];
    //继续开始定时器
    [timer setFireDate:[NSDate date]];
    [self.slideTime setHidden:YES];
}
-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if ([tableView tag]==2) {
        UIButton* button=[[UIButton alloc]initWithFrame:CGRectMake(0,0,self.view.frame.size.width, 40)];
        //    UIButton* button=[[UIButton alloc]initWithFrame:self.view.frame];
        [button setBackgroundColor:[UIColor blackColor]];
        [button setTitle:@"关闭" forState:UIControlStateNormal];
        [button addTarget:self action:@selector(closeList) forControlEvents:UIControlEventTouchUpInside];
        return button;
    }
    return  nil;
    
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if ([tableView tag]==2) {
        return 40;
    }
    return 0;
}
-(void)closeList
{
    [UIView animateWithDuration:0.2 animations:^{
        [self.ListTableview setFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 200)];
    }];
}

-(void)touchSlide
{
    [self.slideTime setHidden:NO];
    [timer setFireDate:[NSDate distantFuture]];
}
-(void)valueChange
{
    int time=self.slider.value* musicPlayer.duration;
    [self.slideTime setTitle:[NSString stringWithFormat:@"%02d:%02d",time/60,time%60] forState:UIControlStateNormal];
    CGPoint temcenter= self.slideTime.center;
    temcenter.x=self.slider.value*self.slider.frame.size.width+centerPointY;
    self.slideTime.center=temcenter;
}

//将状态栏改成白色效果
-(UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}
#pragma mark 初始化界面
- (void)viewDidLoad {
    [super viewDidLoad];
    LRCArry=[NSMutableArray array];
    LRCdic=[NSMutableDictionary dictionary];
    musicArray=[NSMutableArray array];
    musicPlayer.delegate=self;
    self.singerPhoto=[[UIImageView alloc]initWithFrame:CGRectMake(70, 44, 180, 180)];
    [self.thirdView addSubview:self.singerPhoto];
    //给歌曲进度条加上背景图片
    [self.slider setThumbImage:[UIImage imageNamed:@"player_slider_playback_thumb.png"] forState:UIControlStateNormal];
    //初始化音乐
    [self initMusic];
//    musicPlayer.delegate=self;
    [self prepareForMusic:0];
    //给进度条绑定时间
    [self.slider addTarget:self action:@selector(selectTime) forControlEvents:UIControlEventTouchUpInside];
    [self.slider addTarget:self action:@selector(touchSlide) forControlEvents:UIControlEventTouchDown];
    [self.slider addTarget:self action:@selector(valueChange) forControlEvents:UIControlEventValueChanged];
    //进度条上touch出现的时间
    self.slideTime=[[UIButton alloc]initWithFrame:CGRectMake(self.slider.frame.origin.x-20, self.slider.frame.origin.y-20, 50, 20)];
    [self.slideTime setBackgroundImage:[UIImage imageNamed:@"playTime.tiff"] forState:UIControlStateNormal];
    centerPointY=self.slideTime.center.x;
    [self.slideTime setEnabled:NO];
    [self.slideTime setHidden:YES];
    [self.secondView addSubview:self.slideTime];
    lasrPhoto=self.singerPhoto.frame;
    //设定定时器
    timer=[NSTimer scheduledTimerWithTimeInterval:0.1f target:self selector:@selector(show) userInfo:nil repeats:YES];
    [self.LRCLine setNumberOfLines:-1];
    [timer setFireDate:[NSDate distantFuture]];
    self.tableview=[[UITableView alloc]initWithFrame:CGRectMake(self.thirdView.frame.size.width, self.thirdView.frame.origin.y, self.thirdView.frame.size.width, self.thirdView.frame.size.height-50) style:UITableViewStylePlain];
    lastTable=self.tableview.frame;
    
    [self.tableview setDataSource:self];
    [self.tableview setDelegate:self];
    [self.tableview setBackgroundColor:[UIColor clearColor]];
    [self.tableview setSeparatorColor:[UIColor clearColor]];
    [self.tableview setShowsVerticalScrollIndicator:NO];
    [self.tableview setTag:1];
    NSBundle* bund=[NSBundle mainBundle];
    [self.tableview registerNib:[UINib nibWithNibName:@"LjjLRCcell" bundle:bund] forCellReuseIdentifier:@"cell"];
    self.scroller=[[UIScrollView alloc]initWithFrame:self.thirdView.frame];
    [self.scroller setContentSize:CGSizeMake(self.view.frame.size.width*2, self.thirdView.frame.size.height)];
    [self.scroller setScrollEnabled:YES];
    [self.scroller setPagingEnabled:YES];
    [self.scroller setShowsHorizontalScrollIndicator:NO];
    [self.scroller setBackgroundColor:[UIColor clearColor]];
    [self.scroller addSubview:self.singerPhoto];
    [self.scroller addSubview:self.tableview];
    [self.scroller setDelegate:self];
    [self.view addSubview:self.scroller];
    self.ListTableview=[[UITableView alloc]initWithFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 200) style:UITableViewStylePlain];
    [self.ListTableview setDataSource:self];
    [self.ListTableview setDelegate:self];
    [self.ListTableview setBackgroundColor:[UIColor clearColor]];
    [self.ListTableview setSeparatorColor:[UIColor clearColor]];
    [self.ListTableview setShowsVerticalScrollIndicator:NO];
    [self.ListTableview setTag:2];
    [self.ListTableview registerNib:[UINib nibWithNibName:@"ListCell" bundle:bund] forCellReuseIdentifier:@"cell2"];
    [self.view addSubview:self.ListTableview];
    lastlist=self.listButton.frame;
}
#pragma mark 表结构
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==1) {
        return LRCArry.count;
    }
    return musicArray.count;
    
}
-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag==1) {
        LjjLRCcell* cell=[tableView dequeueReusableCellWithIdentifier:@"cell"];
        UIView* view=[[UIView alloc]initWithFrame:cell.frame];
        [view setBackgroundColor:[UIColor clearColor]];
        [cell setSelectedBackgroundView:view];
        [cell setSelectionStyle:UITableViewCellSelectionStyleDefault];
        cell.LRClable.text=[LRCdic objectForKey:LRCArry[indexPath.row]];
        return cell;
    }
    else{
        ListCell* cell=[tableView dequeueReusableCellWithIdentifier:@"cell2"];
        Music* music=musicArray[indexPath.row];
        UIView* view=[[UIView alloc]initWithFrame:cell.frame];
//        [view setBackgroundColor:[UIColor clearColor]];
//        [cell setSelectedBackgroundView:view];
        [cell setSelectionStyle:UITableViewCellSelectionStyleDefault];
        cell.music.text=[NSString stringWithFormat:@"%@-%@",music.musicName,music.singerName];
        [cell.photo setImage:[UIImage imageNamed:[NSString stringWithFormat:@"%@-%@.jpg",music.singerName,music.musicName]]];
        [cell.music setTextColor:[UIColor whiteColor]];
        return cell;
    }
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag==1) {
        NSArray* array=[LRCArry[indexPath.row] componentsSeparatedByString:@":"];
        double LRtime=[array[0] doubleValue]*60 +[array[1] doubleValue];
        musicPlayer.currentTime=LRtime;
    }
    else
    {
        count=indexPath.row;
        [self prepareForMusic:count];
        [self playBUttonClick];
        [UIView animateWithDuration:0.2 animations:^{
            [self.ListTableview setFrame:CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 200)];
        }];
    }
    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag==1) {
        return 40;
    }
    return 70;
    
}
//触摸换屏幕
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y==0 && scrollView.contentOffset.x!=0) {
        [self.thirdView setAlpha:(1-scrollView.contentOffset.x/320)];
        if (scrollView.contentOffset.x==320) {
            isFirst=YES;
        }
        else
        {
            isFirst=NO;
        }
        NSLog(@"%f",scrollView.contentOffset.x);

    }
    
//    NSLog(@"%f",scrollView.contentOffset.x);
    }
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSLog(@"sddff");
}
-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView
{
    NSLog(@"sdasdas");
}
-(void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
//    UITouch* touch=[[event allTouches] anyObject];
//    CGPoint local=[touch locationInView:self.tableview];
//   CGPoint previous=[touch previousLocationInView:self.tableview];
//    [self.thirdView setAlpha:(self.singerPhoto.frame.origin.x+30)/100];
//    CGRect rect=self.singerPhoto.frame;
//    CGRect rect2=self.tableview.frame;
//    rect.origin.x=rect.origin.x+(local.x-previous.x);
//    rect2.origin.x=rect2.origin.x+(local.x-previous.x);;
//    self.singerPhoto.frame=rect;
//    self.tableview.frame=rect2;
}
-(void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event
{
    
    NSLog(@"dasda");
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}

@end
