//
//  ListCell.m
//  LJJMp3Player
//
//  Created by Mac on 15-3-18.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import "ListCell.h"

@implementation ListCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
