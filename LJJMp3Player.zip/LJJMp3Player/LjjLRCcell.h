//
//  LjjLRCcell.h
//  LJJMp3Player
//
//  Created by Mac on 15-3-15.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LjjLRCcell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *LRClable;

@end
