//
//  LjjLRCcell.m
//  LJJMp3Player
//
//  Created by Mac on 15-3-15.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import "LjjLRCcell.h"

@implementation LjjLRCcell

- (void)awakeFromNib {
    // Initialization code
}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    // Configure the view for the selected state
}

@end
