//
//  headView.h
//  LJJMp3Player
//
//  Created by Mac on 15-5-9.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface headView : UIView

@end
