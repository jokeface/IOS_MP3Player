//
//  headView.m
//  LJJMp3Player
//
//  Created by Mac on 15-5-9.
//  Copyright (c) 2015年 LJJ. All rights reserved.
//

#import "headView.h"

@implementation headView

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
